import { useRouter } from 'expo-router';
import React, { useState } from 'react';
import { Modal, StyleSheet, Text, View } from 'react-native';

import { Button, Eyebrow, IconButton, InlinePill, Screen, ScreenScroll } from '@/components/ui';
import { useBar } from '@/state/BarProvider';
import { colors, fonts, radius, spacing } from '@/theme/tokens';

export default function AccountScreen() {
  const router = useRouter();
  const [resetConfirmOpen, setResetConfirmOpen] = useState(false);
  const { snapshot, accountProfile, importState, retryGuestImport, signOut, resetGuest } = useBar();
  const sharedSubmissions = snapshot.productSubmissions.filter((submission) => submission.shareConsent);
  const pendingReviewCount = sharedSubmissions.filter(
    (submission) => submission.status === 'pending_review',
  ).length;

  return (
    <Screen>
      <ScreenScroll contentStyle={styles.scrollContent}>
        <View style={styles.topBar}>
          <IconButton label="Go back" glyph="‹" onPress={() => router.canGoBack() ? router.back() : router.replace('/(tabs)/bar')} />
          <Text style={styles.topLabel}>ACCOUNT & DATA</Text>
          <View style={styles.headerSpacer} />
        </View>

        <Eyebrow>{accountProfile ? 'Local preview active' : 'Optional local preview'}</Eyebrow>
        <Text accessibilityRole="header" style={styles.title}>
          {accountProfile ? 'Your preview bar is ready.' : 'Test migration without leaving this device.'}
        </Text>
        <Text style={styles.subtitle}>
          {accountProfile
            ? 'Your account copy and original guest bar are stored separately on this device.'
            : 'Create a local preview to test guest-data migration. It does not provide authentication, backup or synchronisation.'}
        </Text>

        <View style={styles.previewNotice}>
          <Text style={styles.previewGlyph}>i</Text>
          <View style={styles.previewCopy}>
            <Text style={styles.previewTitle}>Local account preview</Text>
            <Text style={styles.previewBody}>Supabase is not configured in this build. Account screens and idempotent guest migration are testable, but no password is requested and no data leaves this device.</Text>
          </View>
        </View>

        {accountProfile ? (
          <>
            <View style={styles.accountCard}>
              <View style={styles.avatar}><Text style={styles.avatarText}>{accountProfile.email.charAt(0).toUpperCase()}</Text></View>
              <View style={styles.accountCopy}>
                <Text style={styles.email}>{accountProfile.email}</Text>
                <Text style={styles.accountMeta}>Preview account · Created {new Date(accountProfile.createdAt).toLocaleDateString()}</Text>
              </View>
              <InlinePill label="Preview active" tone="ready" />
            </View>

            <View style={styles.importCard}>
              <View style={styles.importHeader}>
                <Text style={styles.importTitle}>Guest data migration</Text>
                <InlinePill
                  label={importState.status === 'confirmed' ? 'Confirmed' : importState.status}
                  tone={importState.status === 'confirmed' ? 'ready' : importState.status === 'failed' ? 'attention' : 'brass'}
                />
              </View>
              {importState.status === 'confirmed' ? (
                <Text style={styles.importBody}>
                  {importState.mergedInventoryCount ?? 0} inventory items · {importState.mergedSavedCount ?? 0} saves · {importState.mergedShoppingCount ?? 0} shopping items copied. The guest source remains intact.
                </Text>
              ) : importState.status === 'failed' ? (
                <>
                  <Text style={styles.importError}>{importState.error ?? 'Import needs another attempt.'}</Text>
                  <Button label="Retry guest import" variant="secondary" onPress={() => void retryGuestImport()} />
                </>
              ) : (
                <Text style={styles.importBody}>The guest import has not completed yet.</Text>
              )}
            </View>

            <View style={styles.actions}>
              <Button label="Edit taste profile" variant="secondary" onPress={() => router.push('/preferences')} />
              <Button label="Open shopping" variant="secondary" onPress={() => router.push('/shopping')} />
              <Button label="Exit preview" variant="ghost" onPress={signOut} />
            </View>
          </>
        ) : (
          <View style={styles.actions}>
            <Button label="Create preview account" onPress={() => router.push('/account/register')} />
            <Button label="Open preview account" variant="secondary" onPress={() => router.push('/account/sign-in')} />
            <Button label="Check preview recovery" variant="ghost" onPress={() => router.push('/account/recovery')} />
          </View>
        )}

        <View style={styles.catalogueSection}>
          <View style={styles.catalogueHeader}>
            <View style={styles.catalogueCopy}>
              <Text style={styles.dataTitle}>Catalogue review preview</Text>
              <Text style={styles.dataBody}>
                Inspect locally simulated product submissions and exercise approval decisions. Nothing is published or shared.
              </Text>
            </View>
            {pendingReviewCount ? <InlinePill label={`${pendingReviewCount} pending`} tone="attention" /> : null}
          </View>
          <Button
            label={sharedSubmissions.length ? 'Open catalogue review' : 'Open empty review queue'}
            variant="secondary"
            onPress={() => router.push('/catalogue' as never)}
          />
        </View>

        <View style={styles.catalogueSection}>
          <View style={styles.catalogueCopy}>
            <Text style={styles.dataTitle}>About, privacy & release status</Text>
            <Text style={styles.dataBody}>See exactly what remains local, what is not connected, and what production launch still requires.</Text>
          </View>
          <Button label="Open release information" variant="secondary" onPress={() => router.push('/about' as never)} />
        </View>

        <View style={styles.dataSection}>
          <Text style={styles.dataTitle}>Guest data on this device</Text>
          <Text style={styles.dataBody}>Use this when you want to repeat onboarding from a clean local state.</Text>
          <Button label="Reset guest bar" variant="danger" onPress={() => setResetConfirmOpen(true)} />
        </View>
      </ScreenScroll>
      <Modal
        visible={resetConfirmOpen}
        transparent
        animationType="fade"
        onRequestClose={() => setResetConfirmOpen(false)}
      >
        <View style={styles.confirmScrim} accessibilityViewIsModal>
          <View style={styles.confirmCard} accessibilityRole="alert">
            <Text accessibilityRole="header" style={styles.confirmTitle}>Reset the guest bar?</Text>
            <Text style={styles.confirmBody}>This clears the separate guest inventory, saves, preferences, shopping and make sessions. A preview-account copy is not changed.</Text>
            <View style={styles.confirmActions}>
              <Button label="Cancel" variant="ghost" onPress={() => setResetConfirmOpen(false)} />
              <Button
                label="Reset guest bar"
                variant="danger"
                onPress={() => {
                  setResetConfirmOpen(false);
                  resetGuest();
                }}
              />
            </View>
          </View>
        </View>
      </Modal>
    </Screen>
  );
}

const styles = StyleSheet.create({
  scrollContent: { paddingBottom: spacing.huge },
  topBar: { flexDirection: 'row', alignItems: 'center', justifyContent: 'space-between', paddingTop: spacing.sm, marginBottom: spacing.xxxl },
  topLabel: { color: colors.paperDim, fontFamily: fonts.bodyMedium, fontSize: 11, letterSpacing: 1.4 },
  headerSpacer: { width: 44 },
  title: { color: colors.paper, fontFamily: fonts.display, fontSize: 43, lineHeight: 49, marginTop: spacing.sm, maxWidth: 650 },
  subtitle: { color: colors.paperMuted, fontFamily: fonts.body, fontSize: 15, lineHeight: 23, maxWidth: 590, marginTop: spacing.md },
  previewNotice: { flexDirection: 'row', gap: spacing.md, marginTop: spacing.xxl, borderRadius: radius.lg, borderWidth: 1, borderColor: 'rgba(215,170,98,0.2)', backgroundColor: colors.brassSoft, padding: spacing.lg },
  previewGlyph: { width: 24, height: 24, borderRadius: 12, backgroundColor: colors.brass, color: colors.ink, textAlign: 'center', lineHeight: 24, fontFamily: fonts.bodyMedium, fontSize: 12 },
  previewCopy: { flex: 1 },
  previewTitle: { color: colors.paper, fontFamily: fonts.bodyMedium, fontSize: 12 },
  previewBody: { color: colors.paperMuted, fontFamily: fonts.body, fontSize: 11, lineHeight: 17, marginTop: 4 },
  accountCard: { flexDirection: 'row', alignItems: 'center', gap: spacing.md, marginTop: spacing.xxxl, borderRadius: radius.lg, borderWidth: 1, borderColor: colors.divider, backgroundColor: colors.surface, padding: spacing.lg },
  avatar: { width: 48, height: 48, borderRadius: 24, backgroundColor: colors.surfaceWarm, alignItems: 'center', justifyContent: 'center' },
  avatarText: { color: colors.brass, fontFamily: fonts.display, fontSize: 23 },
  accountCopy: { flex: 1 },
  email: { color: colors.paper, fontFamily: fonts.bodyMedium, fontSize: 13 },
  accountMeta: { color: colors.paperDim, fontFamily: fonts.body, fontSize: 11, marginTop: 4 },
  importCard: { gap: spacing.md, marginTop: spacing.md, borderRadius: radius.lg, borderWidth: 1, borderColor: colors.divider, backgroundColor: colors.surface, padding: spacing.lg },
  importHeader: { flexDirection: 'row', alignItems: 'center', justifyContent: 'space-between', gap: spacing.md },
  importTitle: { color: colors.paper, fontFamily: fonts.display, fontSize: 21 },
  importBody: { color: colors.paperMuted, fontFamily: fonts.body, fontSize: 11, lineHeight: 17 },
  importError: { color: colors.alert, fontFamily: fonts.body, fontSize: 11, lineHeight: 17 },
  actions: { gap: spacing.sm, marginTop: spacing.xxxl },
  catalogueSection: { gap: spacing.lg, marginTop: spacing.huge, padding: spacing.lg, borderRadius: radius.lg, borderWidth: 1, borderColor: colors.divider, backgroundColor: colors.surface },
  catalogueHeader: { flexDirection: 'row', alignItems: 'flex-start', gap: spacing.md },
  catalogueCopy: { flex: 1 },
  dataSection: { gap: spacing.md, marginTop: spacing.huge, paddingTop: spacing.xl, borderTopWidth: StyleSheet.hairlineWidth, borderTopColor: colors.divider },
  dataTitle: { color: colors.paper, fontFamily: fonts.display, fontSize: 20 },
  dataBody: { color: colors.paperDim, fontFamily: fonts.body, fontSize: 11, lineHeight: 17 },
  confirmScrim: { flex: 1, alignItems: 'center', justifyContent: 'center', padding: spacing.xl, backgroundColor: 'rgba(0,0,0,0.72)' },
  confirmCard: { width: '100%', maxWidth: 460, gap: spacing.md, padding: spacing.xl, borderRadius: radius.xl, borderWidth: 1, borderColor: colors.divider, backgroundColor: colors.surface },
  confirmTitle: { color: colors.paper, fontFamily: fonts.display, fontSize: 28 },
  confirmBody: { color: colors.paperMuted, fontFamily: fonts.body, fontSize: 13, lineHeight: 20 },
  confirmActions: { gap: spacing.sm, marginTop: spacing.sm },
});
